/*
# Create leads table for FocusFlow AI early-access signups

1. New Tables
- `leads`
  - `id` (uuid, primary key, auto-generated)
  - `name` (text, not null) — visitor's full name
  - `email` (text, not null, unique) — visitor's email address
  - `plan_interest` (text, nullable) — which pricing plan they showed interest in
  - `created_at` (timestamptz, defaults to now()) — signup timestamp

2. Security
- Enable RLS on `leads`.
- Allow anyone (anon + authenticated) to INSERT new leads — this is a public
  early-access signup form with no sign-in screen.
- No SELECT/UPDATE/DELETE policies: visitors must never read, modify, or
  delete leads (including their own). Only the backend / service role can.
  This keeps all submitted emails private and prevents enumeration.

3. Notes
- Unique constraint on `email` prevents duplicate signups.
- The frontend lead-capture form inserts name + email; the database stores
  them durably so the "We saved your spot" confirmation is real.
*/

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL UNIQUE,
  plan_interest text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_leads" ON leads;
CREATE POLICY "anon_insert_leads" ON leads FOR INSERT
TO anon, authenticated WITH CHECK (true);
