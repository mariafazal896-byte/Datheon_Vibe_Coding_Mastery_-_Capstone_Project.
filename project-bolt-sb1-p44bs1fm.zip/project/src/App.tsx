import { useState } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Features from '@/components/Features';
import HowItWorks from '@/components/HowItWorks';
import Benefits from '@/components/Benefits';
import Pricing from '@/components/Pricing';
import FAQ from '@/components/FAQ';
import LeadCapture from '@/components/LeadCapture';
import Footer from '@/components/Footer';
import { useTheme } from '@/hooks/useTheme';

export default function App() {
  const { theme, toggleTheme } = useTheme();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const handleSelectPlan = (planName: string) => {
    setSelectedPlan(planName);
  };

  return (
    <div className="min-h-screen bg-white text-navy-900 dark:bg-navy-950 dark:text-navy-100">
      <Navbar theme={theme} onToggleTheme={toggleTheme} />
      <main>
        <Hero />
        <Features />
        <HowItWorks />
        <Benefits />
        <Pricing onSelectPlan={handleSelectPlan} />
        <FAQ />
        <LeadCapture selectedPlan={selectedPlan} />
      </main>
      <Footer />
    </div>
  );
}
