import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    q: 'Is FocusFlow AI free to use?',
    a: 'Yes. The Free plan supports one full course plan with daily scheduling and basic tracking at no cost. Upgrade to Pro anytime for unlimited courses and adaptive rescheduling.',
  },
  {
    q: 'How does the AI build my study plan?',
    a: 'FocusFlow reads your syllabus, deadlines, and available study time, then schedules spaced review and active-recall sessions around your classes. It adapts automatically when you miss a day or a new assignment lands.',
  },
  {
    q: 'Will my data stay private?',
    a: 'Your courses, notes, and study history belong to you. We never sell your data, and you can export or delete everything from your account settings at any time.',
  },
  {
    q: 'Can I use it with my existing calendar?',
    a: 'Yes — connect Google Calendar or Apple Calendar to import classes and deadlines. FocusFlow schedules study sessions around the blocks you already have.',
  },
  {
    q: 'What if I am not a university student?',
    a: 'FocusFlow works for anyone learning on a schedule: college students, bootcamp learners, self-studiers, and exam candidates. The Free plan is a great way to see if it fits your routine.',
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="py-20 sm:py-28">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <span className="section-eyebrow">FAQ</span>
          <h2 className="mt-4 text-3xl font-bold text-navy-900 sm:text-4xl dark:text-white">
            Questions, answered
          </h2>
        </div>

        <div className="mt-12 space-y-3">
          {faqs.map((item, i) => {
            const isOpen = open === i;
            return (
              <div
                key={i}
                className="rounded-2xl border border-navy-100 bg-white dark:border-navy-800 dark:bg-navy-900"
              >
                <button
                  type="button"
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                  aria-expanded={isOpen}
                >
                  <span className="text-sm font-semibold text-navy-900 dark:text-white sm:text-base">
                    {item.q}
                  </span>
                  <ChevronDown
                    className={`h-5 w-5 flex-shrink-0 text-navy-400 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-electric-500' : ''
                    }`}
                    aria-hidden="true"
                  />
                </button>
                <div
                  className={`grid transition-all duration-200 ease-out ${
                    isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                  }`}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-4 text-sm leading-relaxed text-navy-600 dark:text-navy-300">
                      {item.a}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
