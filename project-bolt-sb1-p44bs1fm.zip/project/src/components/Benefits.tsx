import { TrendingUp, Flame, HeartHandshake, Trophy } from 'lucide-react';

const benefits = [
  {
    icon: TrendingUp,
    stat: '3.2x',
    label: 'more material retained',
    desc: 'Spaced review and active recall are scheduled for you, so memory lasts past the exam.',
  },
  {
    icon: Flame,
    stat: '21 days',
    label: 'average study streak',
    desc: 'Small daily wins add up. FocusFlow keeps momentum with gentle, adaptive nudges.',
  },
  {
    icon: HeartHandshake,
    stat: '–41%',
    label: 'reported study stress',
    desc: 'A clear plan removes the constant question of what to work on next.',
  },
  {
    icon: Trophy,
    stat: '92%',
    label: 'hit their grade goal',
    desc: 'Students who follow a FocusFlow plan consistently report meeting or beating their target.',
  },
];

export default function Benefits() {
  return (
    <section id="benefits" className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="section-eyebrow">Benefits</span>
          <h2 className="mt-4 text-3xl font-bold text-navy-900 sm:text-4xl dark:text-white">
            Real results, less stress
          </h2>
          <p className="mt-4 text-lg text-navy-600 dark:text-navy-300">
            Students using FocusFlow study more consistently and feel better doing it.
          </p>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {benefits.map((b) => (
            <div key={b.label} className="card text-center">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-navy-50 text-navy-700 dark:bg-navy-800 dark:text-electric-300">
                <b.icon className="h-6 w-6" aria-hidden="true" />
              </div>
              <p className="mt-5 font-display text-3xl font-extrabold text-gradient">{b.stat}</p>
              <p className="mt-1 text-sm font-semibold text-navy-900 dark:text-white">{b.label}</p>
              <p className="mt-3 text-sm leading-relaxed text-navy-600 dark:text-navy-300">{b.desc}</p>
            </div>
          ))}
        </div>

        <figure className="mt-12 mx-auto max-w-3xl rounded-3xl border border-navy-100 bg-gradient-to-br from-navy-50 to-electric-50/40 p-8 text-center dark:border-navy-800 dark:from-navy-900 dark:to-electric-950/30">
          <blockquote className="text-lg font-medium leading-relaxed text-navy-800 dark:text-navy-100">
            “I used to panic before every exam week. FocusFlow turned my chaos into a plan I could
            actually follow — and I finally have my evenings back.”
          </blockquote>
          <figcaption className="mt-4 text-sm text-navy-500 dark:text-navy-400">
            Maya R. — 3rd year, Biochemistry
          </figcaption>
        </figure>
      </div>
    </section>
  );
}
