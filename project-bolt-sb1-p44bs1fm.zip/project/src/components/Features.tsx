import { Brain, Clock, Bell, LineChart, NotebookPen, ShieldCheck } from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'AI-generated study plans',
    desc: 'Drop in your syllabus and deadlines. FocusFlow builds a day-by-day plan that fits your pace and priorities.',
  },
  {
    icon: Clock,
    title: 'Smart time blocking',
    desc: 'Each session is timed and slotted around your classes, sleep, and breaks — no manual calendar wrangling.',
  },
  {
    icon: Bell,
    title: 'Adaptive reminders',
    desc: 'Nudges that arrive when you actually need them, rescheduled automatically when life gets in the way.',
  },
  {
    icon: LineChart,
    title: 'Progress insights',
    desc: 'See streaks, subject coverage, and time-on-task so you know what is working and where to adjust.',
  },
  {
    icon: NotebookPen,
    title: 'Notes & flashcards',
    desc: 'Capture takeaways and auto-generate review cards tied to the topic you just studied.',
  },
  {
    icon: ShieldCheck,
    title: 'Distraction guard',
    desc: 'Optional focus mode mutes notifications and keeps your sessions on track while you work.',
  },
];

export default function Features() {
  return (
    <section id="features" className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="section-eyebrow">Features</span>
          <h2 className="mt-4 text-3xl font-bold text-navy-900 sm:text-4xl dark:text-white">
            Everything you need to stay on track
          </h2>
          <p className="mt-4 text-lg text-navy-600 dark:text-navy-300">
            Six focused tools that work together to turn your goals into consistent daily progress.
          </p>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <article key={f.title} className="card group hover:-translate-y-1 hover:shadow-glow">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-electric-50 text-electric-600 transition-colors group-hover:bg-electric-500 group-hover:text-white dark:bg-electric-950/40 dark:text-electric-400">
                <f.icon className="h-6 w-6" aria-hidden="true" />
              </div>
              <h3 className="mt-5 text-lg font-semibold text-navy-900 dark:text-white">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-navy-600 dark:text-navy-300">{f.desc}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
