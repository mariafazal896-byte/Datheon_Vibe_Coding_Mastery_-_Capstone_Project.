import { Check, Sparkles } from 'lucide-react';

const plans = [
  {
    name: 'Free',
    price: '$0',
    period: 'forever',
    desc: 'For one course or trying things out.',
    features: [
      '1 active course plan',
      'Daily study schedule',
      'Basic progress tracking',
      'Community support',
    ],
    cta: 'Start free',
    featured: false,
  },
  {
    name: 'Pro',
    price: '$8',
    period: 'per month',
    desc: 'For full-time students who want the edge.',
    features: [
      'Unlimited course plans',
      'Adaptive AI rescheduling',
      'Progress insights & streaks',
      'Notes & flashcards',
      'Focus mode & reminders',
      'Priority email support',
    ],
    cta: 'Start 14-day trial',
    featured: true,
  },
  {
    name: 'Team',
    price: '$19',
    period: 'per month',
    desc: 'For study groups, tutors, and cohorts.',
    features: [
      'Everything in Pro',
      'Up to 10 members',
      'Shared study calendar',
      'Group accountability board',
      'Admin dashboard',
      'Dedicated support channel',
    ],
    cta: 'Contact us',
    featured: false,
  },
];

type Props = {
  onSelectPlan?: (planName: string) => void;
};

export default function Pricing({ onSelectPlan }: Props) {
  return (
    <section id="pricing" className="py-20 sm:py-28 bg-navy-50/60 dark:bg-navy-900/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="section-eyebrow">Pricing</span>
          <h2 className="mt-4 text-3xl font-bold text-navy-900 sm:text-4xl dark:text-white">
            Simple plans for every student
          </h2>
          <p className="mt-4 text-lg text-navy-600 dark:text-navy-300">
            Start free, upgrade when you are ready. Cancel anytime.
          </p>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {plans.map((p) => (
            <div
              key={p.name}
              className={`relative flex flex-col rounded-3xl border p-7 transition-all duration-300 ${
                p.featured
                  ? 'border-electric-400 bg-white shadow-glow dark:border-electric-500 dark:bg-navy-900 lg:-translate-y-2'
                  : 'border-navy-100 bg-white shadow-card hover:shadow-soft dark:border-navy-800 dark:bg-navy-900'
              }`}
            >
              {p.featured && (
                <span className="absolute -top-3 left-1/2 inline-flex -translate-x-1/2 items-center gap-1 rounded-full bg-electric-500 px-3 py-1 text-xs font-semibold text-white shadow-glow">
                  <Sparkles className="h-3 w-3" aria-hidden="true" />
                  Most popular
                </span>
              )}
              <h3 className="text-lg font-semibold text-navy-900 dark:text-white">{p.name}</h3>
              <p className="mt-1 text-sm text-navy-500 dark:text-navy-400">{p.desc}</p>
              <div className="mt-5 flex items-baseline gap-1">
                <span className="font-display text-4xl font-extrabold text-navy-900 dark:text-white">
                  {p.price}
                </span>
                <span className="text-sm text-navy-500 dark:text-navy-400">/ {p.period}</span>
              </div>

              <ul className="mt-6 space-y-3 text-sm">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-navy-700 dark:text-navy-200">
                    <span className="mt-0.5 grid h-5 w-5 flex-shrink-0 place-items-center rounded-full bg-success-100 text-success-600 dark:bg-success-500/15 dark:text-success-400">
                      <Check className="h-3.5 w-3.5" aria-hidden="true" />
                    </span>
                    {f}
                  </li>
                ))}
              </ul>

              <a
                href="#early-access"
                onClick={() => onSelectPlan?.(p.name)}
                className={`mt-7 ${p.featured ? 'btn-primary' : 'btn-secondary'} w-full`}
              >
                {p.cta}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
