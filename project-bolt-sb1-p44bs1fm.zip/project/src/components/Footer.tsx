import { BrainCircuit, Github, Twitter, Linkedin, Mail } from 'lucide-react';

const columns = [
  {
    title: 'Product',
    links: [
      { label: 'Features', href: '#features' },
      { label: 'How it works', href: '#how-it-works' },
      { label: 'Pricing', href: '#pricing' },
      { label: 'FAQ', href: '#faq' },
    ],
  },
  {
    title: 'Company',
    links: [
      { label: 'About', href: '#top' },
      { label: 'Careers', href: '#top' },
      { label: 'Blog', href: '#top' },
      { label: 'Press', href: '#top' },
    ],
  },
  {
    title: 'Support',
    links: [
      { label: 'Help center', href: '#faq' },
      { label: 'Contact', href: 'mailto:hello@focusflow.ai' },
      { label: 'Privacy', href: '#top' },
      { label: 'Terms', href: '#top' },
    ],
  },
];

const socials = [
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Github, href: '#', label: 'GitHub' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
  { icon: Mail, href: 'mailto:hello@focusflow.ai', label: 'Email' },
];

export default function Footer() {
  return (
    <footer className="border-t border-navy-100 bg-navy-50/50 dark:border-navy-800 dark:bg-navy-950">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <a href="#top" className="flex items-center gap-2 font-display text-lg font-bold text-navy-900 dark:text-white">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-electric-500 to-navy-600 text-white">
                <BrainCircuit className="h-5 w-5" aria-hidden="true" />
              </span>
              FocusFlow<span className="text-electric-500"> AI</span>
            </a>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-navy-500 dark:text-navy-400">
              The AI study planner that adapts to your schedule, your goals, and your life.
            </p>
            <div className="mt-5 flex gap-2">
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  className="grid h-9 w-9 place-items-center rounded-lg border border-navy-200 text-navy-600 transition-colors hover:border-electric-300 hover:text-electric-600 dark:border-navy-700 dark:text-navy-300 dark:hover:border-electric-500 dark:hover:text-electric-300"
                >
                  <s.icon className="h-4 w-4" aria-hidden="true" />
                </a>
              ))}
            </div>
          </div>

          {columns.map((col) => (
            <div key={col.title}>
              <h3 className="text-sm font-semibold text-navy-900 dark:text-white">{col.title}</h3>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <a
                      href={l.href}
                      className="text-sm text-navy-500 transition-colors hover:text-electric-600 dark:text-navy-400 dark:hover:text-electric-300"
                    >
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-navy-100 pt-6 dark:border-navy-800 sm:flex-row">
          <p className="text-xs text-navy-400 dark:text-navy-500">
            © {new Date().getFullYear()} FocusFlow AI. All rights reserved.
          </p>
          <p className="text-xs text-navy-400 dark:text-navy-500">
            Made for students, by people who have been there.
          </p>
        </div>
      </div>
    </footer>
  );
}
