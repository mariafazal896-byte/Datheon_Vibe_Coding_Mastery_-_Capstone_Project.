import { Upload, Wand2, Rocket } from 'lucide-react';

const steps = [
  {
    icon: Upload,
    step: '01',
    title: 'Add your courses',
    desc: 'Paste your syllabus, import deadlines, or connect your calendar. FocusFlow reads the details so you do not have to type them.',
  },
  {
    icon: Wand2,
    step: '02',
    title: 'Get your plan',
    desc: 'The AI builds a balanced weekly schedule that prioritizes urgent work and spaces your reviews for long-term retention.',
  },
  {
    icon: Rocket,
    step: '03',
    title: 'Study and adapt',
    desc: 'Follow the plan, log your sessions, and watch FocusFlow reschedule around missed days, new assignments, and energy dips.',
  },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 sm:py-28 bg-navy-50/60 dark:bg-navy-900/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="section-eyebrow">How it works</span>
          <h2 className="mt-4 text-3xl font-bold text-navy-900 sm:text-4xl dark:text-white">
            Three steps to your best semester
          </h2>
          <p className="mt-4 text-lg text-navy-600 dark:text-navy-300">
            From scattered deadlines to a clear daily plan in under five minutes.
          </p>
        </div>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {steps.map((s, i) => (
            <div key={s.step} className="relative">
              <div className="card h-full">
                <div className="flex items-center justify-between">
                  <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-electric-500 to-navy-600 text-white shadow-glow">
                    <s.icon className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <span className="font-display text-3xl font-bold text-navy-100 dark:text-navy-800">
                    {s.step}
                  </span>
                </div>
                <h3 className="mt-5 text-lg font-semibold text-navy-900 dark:text-white">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-navy-600 dark:text-navy-300">{s.desc}</p>
              </div>
              {i < steps.length - 1 && (
                <div
                  className="absolute -right-3 top-1/2 hidden h-px w-6 bg-gradient-to-r from-electric-400 to-navy-400 md:block"
                  aria-hidden="true"
                />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
