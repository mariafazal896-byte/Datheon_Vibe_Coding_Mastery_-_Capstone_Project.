import { useState } from 'react';
import { CheckCircle2, Loader2, Mail, User, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

type Status = 'idle' | 'loading' | 'success' | 'error';

type Props = {
  selectedPlan?: string | null;
};

export default function LeadCapture({ selectedPlan }: Props) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<Status>('idle');
  const [message, setMessage] = useState('');
  const [plan, setPlan] = useState<string | null>(selectedPlan ?? null);

  const emailIsValid = (value: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      setStatus('error');
      setMessage('Please enter your name.');
      return;
    }
    if (!email.trim() || !emailIsValid(email.trim())) {
      setStatus('error');
      setMessage('Please enter a valid email address.');
      return;
    }

    setStatus('loading');
    setMessage('');

    try {
      const { error } = await supabase.from('leads').insert({
        name: name.trim(),
        email: email.trim().toLowerCase(),
        plan_interest: plan,
      });

      if (error) {
        if (error.code === '23505') {
          setStatus('success');
          setMessage("You're already on the list — we'll be in touch soon.");
          return;
        }
        throw error;
      }

      setStatus('success');
      setMessage("You're in! Check your inbox for a confirmation.");
      setName('');
      setEmail('');
    } catch {
      setStatus('error');
      setMessage('Something went wrong on our end. Please try again in a moment.');
    }
  };

  return (
    <section id="early-access" className="py-20 sm:py-28">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl border border-electric-200 bg-gradient-to-br from-navy-900 to-navy-700 p-8 shadow-card sm:p-12 dark:border-electric-800">
          <div className="absolute -right-20 -top-20 h-60 w-60 rounded-full bg-electric-500/30 blur-[90px]" aria-hidden="true" />
          <div className="absolute -bottom-24 -left-10 h-60 w-60 rounded-full bg-navy-500/40 blur-[100px]" aria-hidden="true" />

          <div className="relative text-center">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-electric-200">
              Early access
            </span>
            <h2 className="mt-5 text-3xl font-bold text-white sm:text-4xl">
              Reserve your spot today
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-navy-200">
              Join the early-access waitlist and be the first to try FocusFlow AI. We will only
              email you about launch and your invitation — no spam.
            </p>
          </div>

          <form
            onSubmit={handleSubmit}
            noValidate
            className="relative mx-auto mt-8 max-w-md space-y-4"
          >
            <div>
              <label htmlFor="lead-name" className="mb-1.5 block text-sm font-medium text-navy-100">
                Full name
              </label>
              <div className="relative">
                <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-navy-300" aria-hidden="true" />
                <input
                  id="lead-name"
                  type="text"
                  autoComplete="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-xl border border-white/15 bg-white/10 py-3 pl-10 pr-3 text-sm text-white placeholder-navy-300 transition-colors focus:border-electric-400 focus:bg-white/15"
                  placeholder="Jane Doe"
                  required
                  aria-required="true"
                  disabled={status === 'loading'}
                />
              </div>
            </div>

            <div>
              <label htmlFor="lead-email" className="mb-1.5 block text-sm font-medium text-navy-100">
                Email address
              </label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-navy-300" aria-hidden="true" />
                <input
                  id="lead-email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border border-white/15 bg-white/10 py-3 pl-10 pr-3 text-sm text-white placeholder-navy-300 transition-colors focus:border-electric-400 focus:bg-white/15"
                  placeholder="jane@university.edu"
                  required
                  aria-required="true"
                  disabled={status === 'loading'}
                />
              </div>
            </div>

            <div>
              <label htmlFor="lead-plan" className="mb-1.5 block text-sm font-medium text-navy-100">
                Plan of interest <span className="text-navy-300">(optional)</span>
              </label>
              <select
                id="lead-plan"
                value={plan ?? ''}
                onChange={(e) => setPlan(e.target.value || null)}
                className="w-full rounded-xl border border-white/15 bg-white/10 py-3 px-3 text-sm text-white transition-colors focus:border-electric-400 focus:bg-white/15"
                disabled={status === 'loading'}
              >
                <option value="" className="bg-navy-900">No preference</option>
                <option value="Free" className="bg-navy-900">Free</option>
                <option value="Pro" className="bg-navy-900">Pro</option>
                <option value="Team" className="bg-navy-900">Team</option>
              </select>
            </div>

            <button
              type="submit"
              className="btn-primary w-full bg-electric-500 hover:bg-electric-400"
              disabled={status === 'loading'}
            >
              {status === 'loading' ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                  Saving your spot…
                </>
              ) : (
                'Join the waitlist'
              )}
            </button>

            <p className="text-center text-xs text-navy-300">
              This is an early-access demo form. Your details are saved so we can invite you.
            </p>

            {message && (
              <div
                role="status"
                className={`flex items-start gap-2 rounded-xl px-4 py-3 text-sm ${
                  status === 'success'
                    ? 'bg-success-500/15 text-success-300'
                    : 'bg-error-500/15 text-error-300'
                }`}
              >
                {status === 'success' ? (
                  <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0" aria-hidden="true" />
                ) : (
                  <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0" aria-hidden="true" />
                )}
                <span>{message}</span>
              </div>
            )}
          </form>
        </div>
      </div>
    </section>
  );
}
