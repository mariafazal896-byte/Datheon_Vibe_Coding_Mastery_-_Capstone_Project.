import { ArrowRight, CalendarCheck, Sparkles, Star } from 'lucide-react';

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-28 pb-20 sm:pt-32">
      <div className="absolute inset-0 grid-bg [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_75%)]" aria-hidden="true" />
      <div className="absolute -top-24 left-1/2 h-72 w-[42rem] -translate-x-1/2 rounded-full bg-electric-500/20 blur-[120px] dark:bg-electric-500/15" aria-hidden="true" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <span className="section-eyebrow animate-fade-in">
            <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
            AI study planning, reimagined
          </span>
          <h1 className="mt-6 text-4xl font-extrabold leading-[1.1] text-navy-900 sm:text-5xl lg:text-6xl dark:text-white animate-fade-up">
            Study smarter with a plan that
            <span className="text-gradient"> adapts to you</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-navy-600 dark:text-navy-300 animate-fade-up [animation-delay:80ms]">
            FocusFlow AI turns your syllabus, deadlines, and goals into a personalized study
            schedule that updates as you go — so you always know what to study next.
          </p>
          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row animate-fade-up [animation-delay:160ms]">
            <a href="#early-access" className="btn-primary w-full sm:w-auto">
              Claim your free spot
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </a>
            <a href="#how-it-works" className="btn-secondary w-full sm:w-auto">
              See how it works
            </a>
          </div>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-sm text-navy-500 dark:text-navy-400 animate-fade-up [animation-delay:240ms]">
            <span className="inline-flex items-center gap-1.5">
              <CalendarCheck className="h-4 w-4 text-success-500" aria-hidden="true" />
              No credit card required
            </span>
            <span className="inline-flex items-center gap-1.5">
              <div className="flex -space-x-1" aria-hidden="true">
                {[0, 1, 2, 3].map((i) => (
                  <Star key={i} className="h-4 w-4 fill-electric-400 text-electric-400" />
                ))}
              </div>
              Loved by 4,000+ students
            </span>
          </div>
        </div>

        <div className="relative mx-auto mt-16 max-w-4xl animate-fade-up [animation-delay:320ms]">
          <div className="card overflow-hidden p-0">
            <div className="flex items-center gap-1.5 border-b border-navy-100 px-4 py-3 dark:border-navy-800">
              <span className="h-3 w-3 rounded-full bg-error-400" aria-hidden="true" />
              <span className="h-3 w-3 rounded-full bg-warning-400" aria-hidden="true" />
              <span className="h-3 w-3 rounded-full bg-success-400" aria-hidden="true" />
              <span className="ml-3 text-xs font-medium text-navy-400 dark:text-navy-500">
                focusflow.ai/week-7
              </span>
            </div>
            <div className="grid gap-4 p-5 sm:grid-cols-5">
              <div className="sm:col-span-2 rounded-2xl bg-navy-50 p-4 dark:bg-navy-800/50">
                <p className="text-xs font-semibold uppercase tracking-wider text-electric-600 dark:text-electric-400">
                  Today's focus
                </p>
                <p className="mt-2 font-display text-xl font-bold text-navy-900 dark:text-white">
                  Organic Chem
                </p>
                <p className="mt-1 text-sm text-navy-500 dark:text-navy-400">
                  Reaction mechanisms · 45 min
                </p>
                <div className="mt-4 h-2 w-full rounded-full bg-navy-100 dark:bg-navy-700">
                  <div className="h-2 w-3/4 rounded-full bg-gradient-to-r from-electric-400 to-electric-600" />
                </div>
                <p className="mt-2 text-xs text-navy-400">75% of weekly goal</p>
              </div>
              <div className="sm:col-span-3 space-y-3">
                {[
                  { t: 'Calculus II — Practice set 4', d: '10:30 – 11:30' },
                  { t: 'Literature — Essay outline', d: '13:00 – 14:00' },
                  { t: 'Physics — Review lab notes', d: '16:00 – 16:45' },
                ].map((item) => (
                  <div
                    key={item.t}
                    className="flex items-center justify-between rounded-2xl border border-navy-100 px-4 py-3 dark:border-navy-800"
                  >
                    <div>
                      <p className="text-sm font-semibold text-navy-900 dark:text-white">{item.t}</p>
                      <p className="text-xs text-navy-500 dark:text-navy-400">{item.d}</p>
                    </div>
                    <span className="rounded-full bg-success-100 px-2 py-0.5 text-xs font-medium text-success-700 dark:bg-success-500/15 dark:text-success-400">
                      Scheduled
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
